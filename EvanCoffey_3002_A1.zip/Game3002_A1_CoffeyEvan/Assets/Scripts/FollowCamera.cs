using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowCamera : MonoBehaviour
{

    //setting up some variables for the math used later
    [Header("Follow Camera Offset")]
    public float FollowDistance = 10f;
    public float FollowAngle = 30f;

    [Header("scroll Speed")]
    public float ScrollSpeed = 1.0f;
    public float LookSpeed = 30.0f;
    public float RotationSpeed = 45.0f;

    [Header("Follow Target")]
    public GameObject target;

    public bool LockedCamera = true;

    private float AngleAroundTarget = 0f;

    private float followAngleRadians;
    private float AngleArroundTargetRadians;


    Vector3 OffSet;
    // Start is called before the first frame update
    void Start()
    {
        followAngleRadians = Mathf.Deg2Rad * FollowAngle;
        AngleArroundTargetRadians = Mathf.Deg2Rad * AngleArroundTargetRadians;
        OffSet = new Vector3(0, FollowDistance * Mathf.Sin(followAngleRadians), FollowDistance * Mathf.Cos(followAngleRadians));
        transform.localPosition = OffSet;
    }

    // Update is called once per frame
    void Update()
    {
        //might finish adding unlocked camera
        if (LockedCamera)
        {
            //I moved most of the movement code to seperate functions to clean it up a bit
            Zoom();

            LookVertical();

            RotateCamera();

            //this converts the numbers from degrees, I like degress on y end but the code likes radians
            followAngleRadians = Mathf.Deg2Rad * FollowAngle;
            AngleArroundTargetRadians = Mathf.Deg2Rad * AngleAroundTarget;

           
            
                OffSet = new Vector3(0, FollowDistance * Mathf.Sin(followAngleRadians), FollowDistance * Mathf.Cos(followAngleRadians));
                OffSet = new Vector3(OffSet.z * Mathf.Sin(AngleArroundTargetRadians), OffSet.y, OffSet.z * Mathf.Cos(AngleArroundTargetRadians));

            transform.position = OffSet + target.transform.position;

            transform.LookAt(target.transform);
        }
        else
        {
            if(Input.GetKey(KeyCode.W))
            {
                transform.localPosition += Vector3.forward * Time.deltaTime;
            }
        }
    
    }

    //this changes the follow angle, this angle is basically the x angle
    void LookVertical()
    {
        if (Input.GetKey(KeyCode.W))
        {
                FollowAngle += LookSpeed * Time.deltaTime;
        }

        else if (Input.GetKey(KeyCode.S))
        {
                FollowAngle -= LookSpeed * Time.deltaTime;
        }

        FollowAngle = Mathf.Clamp(FollowAngle, 5, 80);
    }

    //this changes the follow distance, this affects how close to the ball you are
    void Zoom()
    {
            if (Input.mouseScrollDelta.y > 0)
            {
                FollowDistance -= ScrollSpeed * Time.deltaTime;
            }

            else if (Input.mouseScrollDelta.y < 0)
            {
                FollowDistance += ScrollSpeed * Time.deltaTime;
            }

            if (FollowDistance < 1)
            {
                FollowDistance = 1;
            }
    }

    //this changes the rotate angle, the y angle
    void RotateCamera()
    {
        if (Input.GetKey(KeyCode.A))
        {
            AngleAroundTarget += RotationSpeed * Time.deltaTime;
        }
        else if (Input.GetKey(KeyCode.D))
        {
            AngleAroundTarget -= RotationSpeed * Time.deltaTime;
        }
    }
}
