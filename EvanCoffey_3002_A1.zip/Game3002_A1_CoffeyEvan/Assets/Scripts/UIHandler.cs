using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class UIHandler : MonoBehaviour
{
    public GameObject HowToPlayCanvas;
    //loads up level 1
   public void LoadGame()
    {
        SceneManager.LoadScene("Level 1");
    }

    //opens and then closes the howtoPlay screen
    public void HowToPlay()
    {
        HowToPlayCanvas.SetActive(true);
        gameObject.SetActive(false);
    }

    public void CloseHowToPlay()
    {
        HowToPlayCanvas.SetActive(false);
        gameObject.SetActive(true);
    }
}
