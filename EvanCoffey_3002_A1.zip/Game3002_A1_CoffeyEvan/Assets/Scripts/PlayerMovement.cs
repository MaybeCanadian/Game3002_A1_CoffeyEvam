using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{
    [Header("Referances")]
    public Vector3 InitalVelocity = new Vector3(0, 0, 0);
    public float RotationSpeed = 1.0f;
    public Rigidbody rb;
    private GameObject Que;
    public GameObject QuePrefab;

    public float InitalSpeed = 100f;

    public Camera FollowCam;

    public bool Fired = false;

    [Header("Que Values")]
    private Vector3 QueOffSet;
    public float QueAngleX = 180f;
    public float QueAngleY = 0f;
    public float QueDistance = 0.6f;
    public bool QueVisible = true;
    public float QueRotateSpeedX = 30f;
    public float QueuRotateSpeedY = 30f;

    private GameObject Target;
    public GameObject TargetPrefab;


    public string SceneName;

    private int shots = 0;
    private Quaternion startingRot;

    public GameObject NextButton;

    // Start is called before the first frame update
    void Start()
    {
        Target = Instantiate(TargetPrefab);
        startingRot = transform.rotation;
        

        //this part mainly sets up different components
        rb = GetComponent<Rigidbody>();

        rb.velocity = InitalVelocity;

        QueOffSet = new Vector3(0, QueDistance * Mathf.Sin(QueAngleX * Mathf.Deg2Rad), QueDistance * Mathf.Cos(QueAngleX * Mathf.Deg2Rad));
        QueOffSet = new Vector3(QueOffSet.z * Mathf.Sin(QueAngleY * Mathf.Deg2Rad), QueOffSet.y, QueOffSet.z * Mathf.Cos(QueAngleY * Mathf.Deg2Rad));
         

        //I opted to make the que a intantiated object of the player instead of an object just in the game
        Que = Instantiate(QuePrefab);
        

        Vector3 Direction = new Vector3(0, InitalSpeed * Mathf.Sin(QueAngleX * Mathf.Deg2Rad), InitalSpeed * Mathf.Cos(QueAngleX * Mathf.Deg2Rad));
        Direction = new Vector3(Direction.z * Mathf.Sin(QueAngleY * Mathf.Deg2Rad), Direction.y, Direction.z * Mathf.Cos(QueAngleY * Mathf.Deg2Rad));

       
    }

    // Update is called once per frame
    void Update()
    {

        Que.SetActive(QueVisible);

        //reset button
       if(Input.GetKeyDown(KeyCode.R))
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }

        MoveQue();

        //this basically does trig on the yz plane than again on the xz plane to get the 3 components.
        QueOffSet = new Vector3(0, QueDistance * Mathf.Sin(QueAngleX * Mathf.Deg2Rad), QueDistance * Mathf.Cos(QueAngleX * Mathf.Deg2Rad));
        QueOffSet = new Vector3(QueOffSet.z * Mathf.Sin(QueAngleY * Mathf.Deg2Rad), QueOffSet.y, QueOffSet.z * Mathf.Cos(QueAngleY * Mathf.Deg2Rad));

        //this makes the wue be at a certain point around the ball, it uses 2 angles, a y and an x angle to do this.
        Que.transform.position = QueOffSet + transform.position;

        Que.transform.LookAt(transform);

        //this checks f the ball is in air so you cant shoot it while it is aready moving
        if (Fired == false)
        {
            //this does the same math as the que did, it uses to calculations of trig to find the three components. The first finds the z and y, the seccond uses the z to find the real z and the x
            Vector3 Direction = new Vector3(0, InitalSpeed * Mathf.Sin(QueAngleX * Mathf.Deg2Rad), InitalSpeed * Mathf.Cos(QueAngleX * Mathf.Deg2Rad));
            Direction = new Vector3(Direction.z * Mathf.Sin(QueAngleY * Mathf.Deg2Rad), Direction.y, Direction.z * Mathf.Cos(QueAngleY * Mathf.Deg2Rad));

            float Vx = Direction.x;
            float Vy = Direction.y;
            float Vz = Direction.z;

            float gravity = Physics.gravity.y;

            float Angle1 = QueAngleX; //yz angle
            float Angle2 = QueAngleY; //xz angle

            float FlightTime = 2 * (Vy / gravity);

            float XDistance = FlightTime * Vx;
            float ZDistance = FlightTime * Vz;

            //this fires the ball using the above force in direction
            if (Input.GetKeyDown(KeyCode.Space))
            {
                rb.velocity.Set(0, 0, 0);
                transform.rotation = startingRot;
                Fired = true;
                Debug.Log(Direction.magnitude);
                rb.AddRelativeForce(Direction, ForceMode.VelocityChange);
                shots++;
            }

            Vector3 TargteOffset = new Vector3(XDistance, 0, ZDistance);

            if (Fired == false)
                Target.transform.position = transform.position - TargteOffset;

        }
        else
        {
            //this checks if the ball has pretty much stopped and lets you fire again
            if(rb.velocity.magnitude < 1)
            {
                Fired = false;
            }
        }

        //this stops the game
        if(Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }

    }
     
    //I moved most of the movement code to seperate functions as it was really cluttered
    //this one changes the angles we use to determine where to put the que
    void MoveQue()
    {
        if(Input.GetKey(KeyCode.UpArrow))
        {
            QueAngleX += QueRotateSpeedX * Time.deltaTime;
        }
        else if(Input.GetKey(KeyCode.DownArrow))
        {
            QueAngleX -= QueRotateSpeedX * Time.deltaTime;
        }

        QueAngleX = Mathf.Clamp(QueAngleX, -20, 90);

        if(Input.GetKey(KeyCode.RightArrow))
        {
            QueAngleY += QueuRotateSpeedY * Time.deltaTime;
        }
        else if(Input.GetKey(KeyCode.LeftArrow))
        {
            QueAngleY -= QueuRotateSpeedY * Time.deltaTime;
        }
    }

    //this checks if it has hit the goal trigger
    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.CompareTag("Finish"))
        {
            Debug.Log("You Win!");
            NextButton.SetActive(true);
        }
    }
    
    //this allows the slider to change the speed for the ball
    public void ChangeSpeed(float newSpeed)
    {
        InitalSpeed = newSpeed;
        
    }

    //this lets the next button change the scene
    public void ChangeScene()
    {
        SceneManager.LoadScene(SceneName);
    }
}
